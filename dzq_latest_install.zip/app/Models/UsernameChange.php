<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UsernameChange extends Model
{
    protected $table = 'username_change';
}
